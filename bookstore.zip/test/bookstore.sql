/*
Navicat MySQL Data Transfer

Source Server         : UML
Source Server Version : 50515
Source Host           : localhost:3306
Source Database       : bookstore

Target Server Type    : MYSQL
Target Server Version : 50515
File Encoding         : 65001

Date: 2015-05-27 23:21:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for output
-- ----------------------------
DROP TABLE IF EXISTS `output`;
CREATE TABLE `output` (
  `bookID` int(10) NOT NULL,
  `number` int(5) NOT NULL,
  `profits` double(10,1) NOT NULL,
  PRIMARY KEY (`bookID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of output
-- ----------------------------
INSERT INTO `output` VALUES ('1001', '3', '66.0');
INSERT INTO `output` VALUES ('1002', '4', '92.0');
INSERT INTO `output` VALUES ('1003', '10', '280.0');
INSERT INTO `output` VALUES ('1007', '10', '100.0');

-- ----------------------------
-- Table structure for stock
-- ----------------------------
DROP TABLE IF EXISTS `stock`;
CREATE TABLE `stock` (
  `bookID` int(10) NOT NULL,
  `bookName` varchar(25) NOT NULL,
  `bookPublish` varchar(25) NOT NULL,
  `writer` varchar(25) NOT NULL,
  `inPrice` double(10,1) NOT NULL,
  `outPrice` double(10,1) NOT NULL,
  `stockAmount` int(5) NOT NULL,
  PRIMARY KEY (`bookID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of stock
-- ----------------------------
INSERT INTO `stock` VALUES ('1001', '22', '44', '11', '22.0', '33.0', '72');
INSERT INTO `stock` VALUES ('1002', 'Jane.eyre', '华东', 'Charlotte Bronte', '22.0', '45.0', '114');
INSERT INTO `stock` VALUES ('1003', 'PRIDE AND PREJUDICE', 'Chinese education', 'Austen，Jane ', '36.0', '64.0', '20');
INSERT INTO `stock` VALUES ('1004', 'RESURRECTION', '华东', 'Tolstoy，Leo ', '24.0', '41.0', '23');
INSERT INTO `stock` VALUES ('1005', ' ROBINSON CRUSOE', 'jiangnan', 'Defoe, Daniel', '21.0', '40.0', '42');
INSERT INTO `stock` VALUES ('1007', 'sfsdff', 'qrq', 'hkhk', '40.0', '50.0', '23');
