package com.test.ui;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import com.test.dao.Output;
import com.test.dao.OutputDAO;
import com.test.dao.Stock;
import com.test.dao.StockDAO;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class SHOW extends javax.swing.JFrame {
	private static final LayoutManager jPanel1Layout = null;
	private JPanel jPanel1;
	private JScrollPane jScrollPane1;
	private JTable jTable1;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SHOW inst = new SHOW();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public SHOW() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				jPanel1.setLayout(null);
				jPanel1.setBackground(new java.awt.Color(160,210,252));
				{
					jScrollPane1 = new JScrollPane();
					jPanel1.add(jScrollPane1);
					jScrollPane1.setBounds(20, 29, 830, 300);
					{
						TableModel jTable1Model = 
								new DefaultTableModel(
										new Object[][] {},
										new String[] {
											"\u4E66\u53F7", "\u4E66\u540D", "\u51FA\u7248\u793E", 
											"\u4F5C\u8005", "\u8FDB\u4EF7", "\u552E\u4EF7", "\u5E93\u5B58", 
											"\u9500\u552E\u91CF", "\u76C8\u5229" });
						jTable1 = new JTable();
						jTable1.setLayout(null);
						jScrollPane1.setViewportView(jTable1);
						jTable1.setModel(jTable1Model);
						StockDAO stockdao = new StockDAO();
						List<Stock> list = stockdao.findAll();
						OutputDAO outputdao = new OutputDAO();
						List<Output> list2 = outputdao.findAll();
						
						Object[] info = new Object[9];
						for (int i = 0; i < list.size(); i++) 
						{
							info[0] = list.get(i).getBookId();
							info[1] = list.get(i).getBookName();
							info[2] = list.get(i).getBookPublish();
							info[3] = list.get(i).getWriter();
							info[4] = list.get(i).getInPrice();
							info[5] = list.get(i).getOutPrice();
							info[6] = list.get(i).getStockAmount();
							info[7] = 0;
							info[8] = 0;
							
							for (int j = 0; j < list2.size(); j++)
							{
								int a = list2.get(j).getBookId();
								int b = list.get(i).getBookId();
								if(a==b)
								{
									
									info[7] = list2.get(j).getNumber();
									info[8] = list2.get(j).getProfits();
									((DefaultTableModel) jTable1Model).addRow(info);
									break;
								}
							}
							int temp = (int) info[7];
							if(temp==0)
								((DefaultTableModel) jTable1Model).addRow(info);
							
							
							
						}
						jTable1.setRowHeight(30);
						jTable1.setPreferredSize(new java.awt.Dimension(812, 297));
						jTable1.getTableHeader().setBounds(413, 5, 0, 0);
					}

				}
			}
			pack();
			this.setSize(887, 460);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}
	

	public void skip() {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SHOW inst = new SHOW();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}

}
