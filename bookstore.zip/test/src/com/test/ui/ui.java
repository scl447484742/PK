package com.test.ui;

import com.test.dao.Output;
import com.test.dao.OutputDAO;
import com.test.dao.Stock;
import com.test.dao.StockDAO;

public class ui {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stock stock1 = new Stock(12,"123","123","12",123.0,123.0,22);
		StockDAO stock2 = new StockDAO();
		stock2.save(stock1);

	}

}
