package com.test.ui;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

import com.test.service.Management;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class OUT extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JButton jButton1;
	private JTextField jTextField2;
	private JLabel jLabel2;
	private JTextField jTextField1;
	private JLabel jLabel1;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				OUT inst = new OUT();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public OUT() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				jPanel1.setBackground(new java.awt.Color(160,210,252));
				jPanel1.setLayout(null);
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u4e66\u53f7:");
					jLabel1.setFont(new   java.awt.Font("Dialog",   1,   25));
					jLabel1.setBounds(131, 92, 108, 33);
				}
				{
					jTextField1 = new JTextField();
					jPanel1.add(jTextField1);
					jTextField1.setBounds(268, 95, 160, 27);
					jTextField1.addKeyListener(new KeyListener() {  
			            @Override  
			            public void keyTyped(KeyEvent e) {  
			                int temp = e.getKeyChar();  
			                System.out.println(temp);  
			                if(temp == 10){//���س�ʱ  
			                  
			                }else if(temp != 46){   //û�а�С����ʱ  
			                    if(temp != 8){  //û�а�backspaceʱ  
			                        //�������ǲ�����0~9֮�䣻  
			                        if(temp > 57){  
			                            e.consume();    //�������������key�¼�,Ҳ���ǰ��˼����Ժ�û�з�Ӧ;  
			                        }else if(temp < 48){  
			                            e.consume();  
			                        }  
			                    }  
			                }         
			            }  
			           
						
						@Override
						public void keyPressed(KeyEvent e) {
							// TODO Auto-generated method stub
							
						}
						@Override
						public void keyReleased(KeyEvent e) {
							// TODO Auto-generated method stub
							
						}  
			});  
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u6570\u91cf:");
					jLabel2.setFont(new   java.awt.Font("Dialog",   1,   25));
					jLabel2.setBounds(131, 169, 108, 28);
				}
				{
					jTextField2 = new JTextField();
					jPanel1.add(jTextField2);
					jTextField2.setBounds(268, 170, 160, 27);
					jTextField2.addKeyListener(new KeyListener() {  
			            @Override  
			            public void keyTyped(KeyEvent e) {  
			                int temp = e.getKeyChar();  
			                System.out.println(temp);  
			                if(temp == 10){//���س�ʱ  
			                  
			                }else if(temp != 46){   //û�а�С����ʱ  
			                    if(temp != 8){  //û�а�backspaceʱ  
			                        //�������ǲ�����0~9֮�䣻  
			                        if(temp > 57){  
			                            e.consume();    //�������������key�¼�,Ҳ���ǰ��˼����Ժ�û�з�Ӧ;  
			                        }else if(temp < 48){  
			                            e.consume();  
			                        }  
			                    }  
			                }         
			            }  
			           
						
						@Override
						public void keyPressed(KeyEvent e) {
							// TODO Auto-generated method stub
							
						}
						@Override
						public void keyReleased(KeyEvent e) {
							// TODO Auto-generated method stub
							
						}  
			});  
				}
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u5356\uff01");
					jButton1.setFont(new   java.awt.Font("Dialog",   1,   25));
					jButton1.setBounds(428, 272, 100, 45);
					jButton1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							if(jTextField1.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "��Ų���Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							if(jTextField2.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "��������Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							
							int bookID = Integer.parseInt(jTextField1.getText());
							int number = Integer.parseInt(jTextField2.getText());
							Management management = new Management();
							management.outOfStock(bookID,number);
							
							
							
						}
					});
				}
			}
			pack();
			this.setSize(677, 423);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}
	
	public void skip()
    {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				OUT inst = new OUT();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
    }

}
