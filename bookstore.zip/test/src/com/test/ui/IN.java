package com.test.ui;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

import com.test.service.Management;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class IN extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JLabel jLabel5;
	private JTextField jTextField7;
	private JLabel jLabel7;
	private JButton jButton1;
	private JTextField jTextField6;
	private JLabel jLabel6;
	private JTextField jTextField5;
	private JTextField jTextField4;
	private JTextField jTextField3;
	private JTextField jTextField2;
	private JLabel jLabel2;
	private JTextField jTextField1;
	private JLabel jLabel1;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				IN inst = new IN();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public IN() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				jPanel1.setLayout(null);
				jPanel1.setBackground(new java.awt.Color(160,210,252));
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u4e66\u53f7:");
					jLabel1.setFont(new   java.awt.Font("Dialog",   1,   25));
					jLabel1.setBounds(50, 41, 93, 29);
				}
				{
					jTextField1 = new JTextField();
					jPanel1.add(jTextField1);
					jTextField1.setBounds(173, 40, 135, 27);
					jTextField1.addKeyListener(new KeyListener() {  
			            @Override  
			            public void keyTyped(KeyEvent e) {  
			                int temp = e.getKeyChar();  
			                System.out.println(temp);  
			                if(temp == 10){//���س�ʱ  
			                  
			                }else if(temp != 46){   //û�а�С����ʱ  
			                    if(temp != 8){  //û�а�backspaceʱ  
			                        //�������ǲ�����0~9֮�䣻  
			                        if(temp > 57){  
			                            e.consume();    //�������������key�¼�,Ҳ���ǰ��˼����Ժ�û�з�Ӧ;  
			                        }else if(temp < 48){  
			                            e.consume();  
			                        }  
			                    }  
			                }         
			            }  
			           
						
						@Override
						public void keyPressed(KeyEvent e) {
							// TODO Auto-generated method stub
							
						}
						@Override
						public void keyReleased(KeyEvent e) {
							// TODO Auto-generated method stub
							
						}  
			});  
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u4e66\u540d:");
					jLabel2.setFont(new   java.awt.Font("Dialog",   1,   25));
					jLabel2.setBounds(50, 115, 93, 20);
				}
				{
					jTextField2 = new JTextField();
					jPanel1.add(jTextField2);
					jTextField2.setBounds(173, 108, 135, 27);
				}
				{
					jLabel3 = new JLabel();
					jPanel1.add(jLabel3);
					jLabel3.setText("\u51fa\u7248\u793e:");
					jLabel3.setFont(new   java.awt.Font("Dialog",   1,   25));
					jLabel3.setBounds(50, 183, 93, 20);
				}
				{
					jTextField3 = new JTextField();
					jPanel1.add(jTextField3);
					jTextField3.setBounds(173, 183, 135, 27);
				}
				{
					jLabel4 = new JLabel();
					jPanel1.add(jLabel4);
					jLabel4.setText("\u4f5c\u8005:");
					jLabel4.setFont(new   java.awt.Font("Dialog",   1,   25));
					jLabel4.setBounds(390, 38, 94, 28);
				}
				{
					jTextField4 = new JTextField();
					jPanel1.add(jTextField4);
					jTextField4.setBounds(513, 42, 144, 27);
				}
				{
					jLabel5 = new JLabel();
					jPanel1.add(jLabel5);
					jLabel5.setText("\u8fdb\u4ef7:");
					jLabel5.setFont(new   java.awt.Font("Dialog",   1,   25));
					jLabel5.setBounds(390, 112, 94, 27);
					
				}
				{
					jTextField5 = new JTextField();
					jPanel1.add(jTextField5);
					jTextField5.setBounds(513, 108, 144, 27);
					jTextField5.addKeyListener(new KeyListener() {  
			            @Override  
			            public void keyTyped(KeyEvent e) {  
			                int temp = e.getKeyChar();  
			                System.out.println(temp);  
			                if(temp == 10){//���س�ʱ  
			                  
			                }else if(temp != 46){   //û�а�С����ʱ  
			                    if(temp != 8){  //û�а�backspaceʱ  
			                        //�������ǲ�����0~9֮�䣻  
			                        if(temp > 57){  
			                            e.consume();    //�������������key�¼�,Ҳ���ǰ��˼����Ժ�û�з�Ӧ;  
			                        }else if(temp < 48){  
			                            e.consume();  
			                        }  
			                    }  
			                }         
			            }  
			           
						
						@Override
						public void keyPressed(KeyEvent e) {
							// TODO Auto-generated method stub
							
						}
						@Override
						public void keyReleased(KeyEvent e) {
							// TODO Auto-generated method stub
							
						}  
			});  
				}
				{
					jLabel6 = new JLabel();
					jPanel1.add(jLabel6);
					jLabel6.setText("\u552e\u4ef7:");
					jLabel6.setFont(new   java.awt.Font("Dialog",   1,   25));
					jLabel6.setBounds(390, 183, 94, 27);
				}
				{
					jTextField6 = new JTextField();
					jPanel1.add(jTextField6);
					jTextField6.setBounds(513, 183, 144, 27);
					jTextField6.addKeyListener(new KeyListener() {  
			            @Override  
			            public void keyTyped(KeyEvent e) {  
			                int temp = e.getKeyChar();  
			                System.out.println(temp);  
			                if(temp == 10){//���س�ʱ  
			                  
			                }else if(temp != 46){   //û�а�С����ʱ  
			                    if(temp != 8){  //û�а�backspaceʱ  
			                        //�������ǲ�����0~9֮�䣻  
			                        if(temp > 57){  
			                            e.consume();    //�������������key�¼�,Ҳ���ǰ��˼����Ժ�û�з�Ӧ;  
			                        }else if(temp < 48){  
			                            e.consume();  
			                        }  
			                    }  
			                }         
			            }  
			           
						
						@Override
						public void keyPressed(KeyEvent e) {
							// TODO Auto-generated method stub
							
						}
						@Override
						public void keyReleased(KeyEvent e) {
							// TODO Auto-generated method stub
							
						}  
			});  
				}
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u5165\u5e93");
					jButton1.setFont(new   java.awt.Font("Dialog",   1,   25));
					jButton1.setBounds(564, 322, 93, 49);
					jButton1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							
							
								
								if(jTextField1.getText().equals(""))
								{
									JOptionPane.showConfirmDialog(null, "��Ų���Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
									return;
								}
								if(jTextField2.getText().equals(""))
								{
									JOptionPane.showConfirmDialog(null, "��������Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
									return;
								}
								if(jTextField3.getText().equals(""))
								{
									JOptionPane.showConfirmDialog(null, "�����粻��Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
									return;
								}
								if(jTextField4.getText().equals(""))
								{
									JOptionPane.showConfirmDialog(null, "���߲���Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
									return;
								}
								if(jTextField5.getText().equals(""))
								{
									JOptionPane.showConfirmDialog(null, "���۲���Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
									return;
								}
								if(jTextField6.getText().equals(""))
								{
									JOptionPane.showConfirmDialog(null, "�ۼ۲���Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
									return;
								}
								if(jTextField7.getText().equals(""))
								{
									JOptionPane.showConfirmDialog(null, "��������Ϊ�գ�����Ϊ0�������޸Ŀ����Ϣ��","��ʾ:", JOptionPane.CLOSED_OPTION);
									return;
								}
								int bookID = Integer.parseInt(jTextField1.getText());
								int inPrice = Integer.parseInt(jTextField5.getText());
								int outPrice = Integer.parseInt(jTextField6.getText());
								int stockAmount = Integer.parseInt(jTextField7.getText());
								Management management = new Management();
								management.addToStock(bookID, jTextField2.getText(), jTextField3.getText(), jTextField4.getText(), inPrice, outPrice, stockAmount);
								JOptionPane.showConfirmDialog(null, "���/�޸ĳɹ���","��ʾ:", JOptionPane.CLOSED_OPTION);
						}
					});
				}
				{
					jLabel7 = new JLabel();
					jPanel1.add(jLabel7);
					jLabel7.setText("\u65b0\u8fdb\u6570\u91cf:");
					jLabel7.setFont(new   java.awt.Font("Dialog",   1,   25));
					jLabel7.setBounds(50, 250, 111, 31);
				}
				{
					jTextField7 = new JTextField();
					jPanel1.add(jTextField7);
					jTextField7.setBounds(173, 250, 135, 27);
					jTextField7.addKeyListener(new KeyListener() {  
			            @Override  
			            public void keyTyped(KeyEvent e) {  
			                int temp = e.getKeyChar();  
			                System.out.println(temp);  
			                if(temp == 10){//���س�ʱ  
			                  
			                }else if(temp != 46){   //û�а�С����ʱ  
			                    if(temp != 8){  //û�а�backspaceʱ  
			                        //�������ǲ�����0~9֮�䣻  
			                        if(temp > 57){  
			                            e.consume();    //�������������key�¼�,Ҳ���ǰ��˼����Ժ�û�з�Ӧ;  
			                        }else if(temp < 48){  
			                            e.consume();  
			                        }  
			                    }  
			                }         
			            }  
			           
						
						@Override
						public void keyPressed(KeyEvent e) {
							// TODO Auto-generated method stub
							
						}
						@Override
						public void keyReleased(KeyEvent e) {
							// TODO Auto-generated method stub
							
						}  
			});  
				}
			}
			pack();
			this.setSize(769, 454);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}
        public void skip()
        {
        	SwingUtilities.invokeLater(new Runnable() {
    			public void run() {
    				IN inst = new IN();
    				inst.setLocationRelativeTo(null);
    				inst.setVisible(true);
    			}
    		});
        }

}
