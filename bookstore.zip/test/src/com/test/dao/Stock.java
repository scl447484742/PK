package com.test.dao;

/**
 * Stock entity. @author MyEclipse Persistence Tools
 */

public class Stock implements java.io.Serializable {

	// Fields

	private Integer bookId;
	private String bookName;
	private String bookPublish;
	private String writer;
	private Double inPrice;
	private Double outPrice;
	private Integer stockAmount;

	// Constructors

	/** default constructor */
	public Stock() {
	}

	/** full constructor */
	public Stock(Integer bookId, String bookName, String bookPublish,
			String writer, Double inPrice, Double outPrice, Integer stockAmount) {
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookPublish = bookPublish;
		this.writer = writer;
		this.inPrice = inPrice;
		this.outPrice = outPrice;
		this.stockAmount = stockAmount;
	}

	// Property accessors

	public Integer getBookId() {
		return this.bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return this.bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getBookPublish() {
		return this.bookPublish;
	}

	public void setBookPublish(String bookPublish) {
		this.bookPublish = bookPublish;
	}

	public String getWriter() {
		return this.writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public Double getInPrice() {
		return this.inPrice;
	}

	public void setInPrice(Double inPrice) {
		this.inPrice = inPrice;
	}

	public Double getOutPrice() {
		return this.outPrice;
	}

	public void setOutPrice(Double outPrice) {
		this.outPrice = outPrice;
	}

	public Integer getStockAmount() {
		return this.stockAmount;
	}

	public void setStockAmount(Integer stockAmount) {
		this.stockAmount = stockAmount;
	}

}