package com.test.dao;

/**
 * Output entity. @author MyEclipse Persistence Tools
 */

public class Output implements java.io.Serializable {

	// Fields

	private Integer bookId;
	private Integer number;
	private Double profits;

	// Constructors

	/** default constructor */
	public Output() {
	}

	/** full constructor */
	public Output(Integer bookId, Integer number, Double profits) {
		this.bookId = bookId;
		this.number = number;
		this.profits = profits;
	}

	// Property accessors

	public Integer getBookId() {
		return this.bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public Integer getNumber() {
		return this.number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public Double getProfits() {
		return this.profits;
	}

	public void setProfits(Double profits) {
		this.profits = profits;
	}

}