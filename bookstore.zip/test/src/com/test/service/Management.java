package com.test.service;

import javax.swing.JOptionPane;

import com.test.dao.Output;
import com.test.dao.OutputDAO;
import com.test.dao.Stock;
import com.test.dao.StockDAO;
import com.test.factory.HibernateSessionFactory;

public class Management 
{
	//���
	public void addToStock(int bookID,String bookName,String bookPublish,String writer,double inPrice,double outPrice,int stockAmount)
	{
		StockDAO stock = new StockDAO();
		if(stock.findById(bookID)!=null)
		{
			int newAmount =stock.findById(bookID).getStockAmount()+stockAmount;
			Stock stock1 = new Stock(bookID,bookName,bookPublish,writer,inPrice,outPrice,newAmount);
			StockDAO stock2 = new StockDAO();
			HibernateSessionFactory.getSession().clear();
			stock2.save(stock1);
			HibernateSessionFactory.getSession().flush();
			JOptionPane.showConfirmDialog(null, "���/�޸ĳɹ���","��ʾ:", JOptionPane.CLOSED_OPTION);
		}
		else
		{
			Stock stock1 = new Stock(bookID,bookName,bookPublish,writer,inPrice,outPrice,stockAmount);
			StockDAO stock2 = new StockDAO();
			HibernateSessionFactory.getSession().clear();
			stock2.save(stock1);
			HibernateSessionFactory.getSession().flush();
			JOptionPane.showConfirmDialog(null, "���/�޸ĳɹ���","��ʾ:", JOptionPane.CLOSED_OPTION);
		}
		
	}
	//����
	public void outOfStock(int bookID,int number)
	{
		StockDAO stock = new StockDAO();
		if(stock.findById(bookID)==null)
		{
			JOptionPane.showConfirmDialog(null, "δ�ҵ�����鼮��","��ʾ:", JOptionPane.CLOSED_OPTION);
			return;
		}
		
		if(stock.findById(bookID).getStockAmount() < number)
		{
			JOptionPane.showConfirmDialog(null, "��治�㣡","��ʾ:", JOptionPane.CLOSED_OPTION);
			return;
		}
		
			
			int newNumber = stock.findById(bookID).getStockAmount() - number;
			
			String bookName = stock.findById(bookID).getBookName();
			
			String bookPublish = stock.findById(bookID).getBookPublish();
			
			String writer = stock.findById(bookID).getWriter();
			
			double inPrice = stock.findById(bookID).getInPrice();
			
			double outPrice = stock.findById(bookID).getOutPrice();
			
			stock.delete(stock.findById(bookID));
			
			Stock stock2 = new Stock(bookID,bookName,bookPublish,writer,inPrice,outPrice,newNumber);
			
			HibernateSessionFactory.getSession().clear();
			stock.save(stock2);
			HibernateSessionFactory.getSession().flush();
			
			
			
		
		
		
			OutputDAO out = new OutputDAO();
		if(out.findById(bookID)!=null)
		{
			int putNumber = out.findById(bookID).getNumber() + number;
			double profits = (outPrice - inPrice) * number + out.findById(bookID).getProfits();
			int newNumber2 = out.findById(bookID).getNumber()+number;
			Output out1 = new Output(bookID,newNumber2,profits);
			OutputDAO out2 = new OutputDAO();
			HibernateSessionFactory.getSession().clear();
			out2.save(out1);
			HibernateSessionFactory.getSession().flush();
			JOptionPane.showConfirmDialog(null,"����ɹ���","��ʾ:", JOptionPane.CLOSED_OPTION);
		}
		else
		{
			double profits = (outPrice - inPrice) * number;
			Output out1 = new Output(bookID,number,profits);
			OutputDAO out2 = new OutputDAO();
			HibernateSessionFactory.getSession().clear();
			out2.save(out1);
			HibernateSessionFactory.getSession().flush();
			JOptionPane.showConfirmDialog(null,"����ɹ���","��ʾ:", JOptionPane.CLOSED_OPTION);
		}
		
		
		
	}
	
	
}
